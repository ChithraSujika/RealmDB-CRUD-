package com.example.myapplication.Interfaces;

import com.example.myapplication.RealmClasses.ProductsRealm;

public interface UserDeleteInterface {
    void deleteUser(int position, String userUUID);
}
